require 'application_system_test_case'

class TreatmentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit treatments_url
  #
  #   assert_selector "h1", text: "Treatment"
  # end
end
