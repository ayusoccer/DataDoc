require 'application_system_test_case'

class BillingstatementsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit billingstatements_url
  #
  #   assert_selector "h1", text: "Billingstatement"
  # end
end
