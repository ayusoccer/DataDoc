require 'application_system_test_case'

class PatientsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit patients_url
  #
  #   assert_selector "h1", text: "Patient"
  # end
end
