require 'test_helper'

class BillingstatementTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
