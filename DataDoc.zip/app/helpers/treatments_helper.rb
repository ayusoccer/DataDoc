module TreatmentsHelper
end
